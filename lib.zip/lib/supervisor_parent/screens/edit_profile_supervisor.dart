import 'dart:async';
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:school_account/supervisor_parent/components/elevated_simple_button.dart';
import 'package:school_account/supervisor_parent/components/supervisor_drawer.dart';
import 'package:school_account/main.dart';
import 'package:school_account/supervisor_parent/screens/attendence_supervisor.dart';
import 'package:school_account/supervisor_parent/screens/edit_add_parent.dart';
import 'package:school_account/supervisor_parent/screens/home_supervisor.dart';
import 'package:school_account/supervisor_parent/screens/notification_supervisor.dart';
import 'package:school_account/supervisor_parent/screens/profile_supervisor.dart';
import 'package:school_account/supervisor_parent/screens/track_supervisor.dart';


class EditProfileSupervisorScreen extends StatefulWidget {
  final String docid;
  final String oldName;
  final String oldEmail;
  final String oldPhoto;
  final String oldNumber;

  const EditProfileSupervisorScreen({super.key,
    required this.docid,
    required this.oldName,
    required this.oldEmail,
    required this.oldNumber,
    required this.oldPhoto ,});
  @override
  _EditProfileSupervisorScreenState createState() => _EditProfileSupervisorScreenState();
}

class _EditProfileSupervisorScreenState extends State<EditProfileSupervisorScreen> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final _phoneNumberController = TextEditingController();
  final _emailController = TextEditingController();
  final _nameController = TextEditingController();
  bool nameError = true;
  bool phoneError = true;
  bool emailError = true;
  File ? _selectedImage;
  String? imageUrl;
  File? file ;
  GlobalKey<FormState> formState = GlobalKey<FormState>();
  CollectionReference Supervisor = FirebaseFirestore.instance.collection('supervisor');
  // List<ChildDataItem> children = [];

  Future _pickImageFromGallery() async{
    final returnedImage= await ImagePicker().pickImage(source: ImageSource.gallery);
    if(returnedImage ==null) return;
    setState(() {
      _selectedImage=File(returnedImage.path);
    });

    //Get a reference to storage root
    Reference referenceRoot = FirebaseStorage.instance.ref();
    Reference referenceDirImages = FirebaseStorage.instance.ref().child('images_supervisor');
    Reference referenceImageToUpload =referenceDirImages.child('profile_supervisor');
    try {
      //Store the file
      await referenceImageToUpload.putFile(File(returnedImage.path));
      //Success: get the download URL
      imageUrl = await referenceImageToUpload.getDownloadURL();
      print('Image uploaded successfully. URL: $imageUrl');
      setState(() {

      });
      return imageUrl;
    } catch (error) {
      print('Error uploading image: $error');
      return '';
      //Some error occurred
    }
  }


  editAddSupervisor() async {
    print('editAddParent called');
    if (formState.currentState != null) {
      print('formState.currentState is not null');
      if (formState.currentState!.validate()) {
        print('form is valid');
        try {
          setState(() {

          });
          print('updating document...');

          await Supervisor.doc(widget.docid).update({
            'phoneNumber': _phoneNumberController.text,
            'name': _nameController.text,
            'email': _emailController.text,
            'busphoto':imageUrl,


          });
          print('document updated successfully');

          setState(() {
            // _pickImageFromGallery();
            });
        } catch (e) {
          print('Error updating document: $e');
        }
      } else {
        print('form is not valid');
      }
    } else {
      print('formState.currentState is null');
    }
  }

  @override
  void initState() {
    super.initState();
    _nameController.text = widget.oldName!;
    _phoneNumberController.text = widget.oldNumber!;
    _emailController.text = widget.oldEmail!;
    imageUrl= widget.oldPhoto;
    setState(() {

    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        endDrawer: SupervisorDrawer(),
        key: _scaffoldKey,
        appBar: PreferredSize(
          child: Container(
            decoration: BoxDecoration(boxShadow: [
              BoxShadow(
                color: Color(0x3F000000),
                blurRadius: 12,
                offset: Offset(-1, 4),
                spreadRadius: 0,
              )
            ]),
            child: AppBar(
              toolbarHeight: 70,
              centerTitle: true,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.vertical(
                  bottom: Radius.circular(16.49),
                ),
              ),
              elevation: 0.0,
              leading: GestureDetector(
                onTap: () {
                  Navigator.of(context).pop();
                },
                child: Padding(
                  padding: (sharedpref?.getString('lang') == 'ar')?
                  EdgeInsets.all( 23.0):
                  EdgeInsets.all( 17.0),
                  child: Image.asset(
                    (sharedpref?.getString('lang') == 'ar')
                        ? 'assets/images/Layer 1.png'
                        : 'assets/images/fi-rr-angle-left.png',
                    width: 10,
                    height: 22,
                  ),
                ),
              ),
              actions: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: GestureDetector(
                    onTap: () {
                      _scaffoldKey.currentState!.openEndDrawer();
                    },
                    child: const Icon(
                      Icons.menu_rounded,
                      color: Color(0xff442B72),
                      size: 35,
                    ),
                  ),
                ),
              ],
              title: Text(
                'Edit Profile'.tr,
                style: const TextStyle(
                  color: Color(0xFF993D9A),
                  fontSize: 17,
                  fontFamily: 'Poppins-Bold',
                  fontWeight: FontWeight.w700,
                  height: 1,
                ),
              ),
              backgroundColor: Color(0xffF8F8F8),
              surfaceTintColor: Colors.transparent,
            ),
          ),
          preferredSize: Size.fromHeight(70),
        ),
        // Custom().customAppBar(context, 'Profile'.tr),
        body: Form(
          key: formState,
          child: SingleChildScrollView(
              child:
              // children.isNotEmpty?
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 30.0),
                    child: SizedBox(
                      width: 230,
                      child: Padding(
                        padding:(sharedpref?.getString('lang') == 'ar')?
                        EdgeInsets.only(right: 120.0 ):
                        EdgeInsets.only(left: 120.0 ),
                        child: Stack(
                          children: [
                            GestureDetector(
                              onTap: (){
                                _pickImageFromGallery();
                                print('edit');
                              },
                              child:  CircleAvatar(
                                  radius: 52.5,
                                  backgroundColor: Color(0xff442B72),
                                  child: CircleAvatar(
                                    backgroundImage: NetworkImage( '$imageUrl',),
                                    radius: 50.5,)
                              ),
                            ),
                            (sharedpref?.getString('lang') == 'ar')?
                            Positioned(
                              bottom: 2,
                              left: 10,
                              child:  Container(
                                  width: 24,
                                  height: 24,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    // shape: BoxShape.circle,
                                    border: Border.all(
                                      color: Color(0xff442B72),
                                      width: 2.0,
                                    ),
                                    borderRadius: BorderRadius.all(Radius.circular(50.0),),),
                                  child: Padding(
                                    padding: const EdgeInsets.all(3.0),
                                    child: Image.asset(
                                      'assets/images/image-editing 1.png' ,),
                                  )
                              ),
                            ):
                            Positioned(
                              bottom: 2,
                              right: 10,
                              child:  Container(
                                  width: 24,
                                  height: 24,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    // shape: BoxShape.circle,
                                    border: Border.all(
                                      color: Color(0xff442B72),
                                      width: 2.0,
                                    ),
                                    borderRadius: BorderRadius.all(Radius.circular(50.0),),),
                                  child: Padding(
                                    padding: const EdgeInsets.all(3.0),
                                    child: Image.asset(
                                      'assets/images/image-editing 1.png' ,),
                                  )
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 18,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 40.0),
                    child:
                    Text.rich(
                      TextSpan(
                        children: [
                          TextSpan(
                            text: 'Name'.tr,
                            style: TextStyle(
                              color: Color(0xFF442B72),
                              fontSize: 15,
                              fontFamily: 'Poppins-Bold',
                              fontWeight: FontWeight.w700,
                              height: 1.07,
                            ),
                          ),
                          TextSpan(
                            text: ' *',
                            style: TextStyle(
                              color: Colors.red,
                              fontSize: 15,
                              fontFamily: 'Poppins-Bold',
                              fontWeight: FontWeight.w700,
                              height: 1.07,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ) ,
                  SizedBox(height: 10,),
                  Center(
                    child: SizedBox(
                      width: 277,
                      height: 38,
                      child: TextFormField(
                        style: TextStyle(
                          color: Color(0xFF442B72),
                      ),
                        controller: _nameController,
                        cursorColor: const Color(0xFF442B72),
                        textDirection: (sharedpref?.getString('lang') == 'ar') ?
                        TextDirection.rtl:
                        TextDirection.ltr,
                        scrollPadding:  EdgeInsets.symmetric(
                            vertical: 30),
                        decoration:  InputDecoration(
                          alignLabelWithHint: true,
                          counterText: "",
                          fillColor: const Color(0xFFF1F1F1),
                          filled: true,
                          contentPadding:
                          (sharedpref?.getString('lang') == 'ar') ?
                          EdgeInsets.fromLTRB(0, 0, 17, 40):
                          EdgeInsets.fromLTRB(17, 0, 0, 40),
                          hintText:''.tr,
                          floatingLabelBehavior:  FloatingLabelBehavior.never,
                          hintStyle: const TextStyle(
                            color: Color(0xFF442B72),
                            fontSize: 12,
                            fontFamily: 'Poppins-Light',
                            fontWeight: FontWeight.w400,
                            height: 1.33,
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(7)),
                            borderSide: BorderSide(
                              color: Color(0xFF442B72),
                              width: 0.5,
                            ),),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(7)),
                            borderSide: BorderSide(
                              color: Color(0xFF442B72),
                              width: 0.5,
                            ),
                          ),
                          // enabledBorder: myInputBorder(),
                          // focusedBorder: myFocusBorder(),
                        ),
                      ),
                    ),
                  ),
                  nameError ? Container(): Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 48),
                    child: Text(
                      "Please enter your name".tr,
                      style: TextStyle(color: Colors.red),
                    ),
                  ),
                  SizedBox(
                    height: 18,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 40.0),
                    child:
                    Text.rich(
                      TextSpan(
                        children: [
                          TextSpan(
                            text: 'Number'.tr,
                            style: TextStyle(
                              color: Color(0xFF442B72),
                              fontSize: 15,
                              fontFamily: 'Poppins-Bold',
                              fontWeight: FontWeight.w700,
                              height: 1.07,
                            ),
                          ),
                          TextSpan(
                            text: ' *',
                            style: TextStyle(
                              color: Colors.red,
                              fontSize: 15,
                              fontFamily: 'Poppins-Bold',
                              fontWeight: FontWeight.w700,
                              height: 1.07,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ) ,
                  SizedBox(height: 10,),
                  Center(
                    child: SizedBox(
                      width: 277,
                      height: 38,
                      child: TextFormField(
                        style: TextStyle(
                          color: Color(0xFF442B72),
                        ),
                        controller: _phoneNumberController,
                        cursorColor: const Color(0xFF442B72),
                        textDirection: (sharedpref?.getString('lang') == 'ar') ?
                        TextDirection.rtl:
                        TextDirection.ltr,
                        keyboardType: TextInputType.number,
                        inputFormatters: <TextInputFormatter>[
                          LengthLimitingTextInputFormatter(11),
                          FilteringTextInputFormatter.digitsOnly],
                        scrollPadding:  EdgeInsets.symmetric(
                            vertical: 30),
                        decoration:  InputDecoration(
                          alignLabelWithHint: true,
                          counterText: "",
                          fillColor: const Color(0xFFF1F1F1),
                          filled: true,
                          contentPadding:
                          (sharedpref?.getString('lang') == 'ar') ?
                          EdgeInsets.fromLTRB(0, 0, 17, 40):
                          EdgeInsets.fromLTRB(17, 0, 0, 40),
                          hintText:''.tr,
                          floatingLabelBehavior:  FloatingLabelBehavior.never,
                          hintStyle: const TextStyle(
                            color: Color(0xFF442B72),
                            fontSize: 12,
                            fontFamily: 'Poppins-Light',
                            fontWeight: FontWeight.w400,
                            height: 1.33,
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(7)),
                            borderSide: BorderSide(
                              color: Color(0xFF442B72),
                              width: 0.5,
                            ),),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(7)),
                            borderSide: BorderSide(
                              color: Color(0xFF442B72),
                              width: 0.5,
                            ),
                          ),
                          // enabledBorder: myInputBorder(),
                          // focusedBorder: myFocusBorder(),
                        ),
                      ),
                    ),
                  ),
                  phoneError ? Container(): Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 48),
                    child: Text(
                      "Please enter your phone Number".tr,
                      style: TextStyle(color: Colors.red),
                    ),
                  ),
                  SizedBox(
                    height: 18,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 40.0),
                    child:
                      Text(
                       'Email'.tr,
                        style: TextStyle(
                          color: Color(0xFF442B72),
                          fontSize: 15,
                          fontFamily: 'Poppins-Bold',
                          fontWeight: FontWeight.w700,
                          height: 1.07,
                        ),
                      ),
                  ) ,
                  SizedBox(height: 10,),
                  Center(
                    child: SizedBox(
                      width: 277,
                      height: 38,
                      child: TextFormField(
                        style: TextStyle(
                          color: Color(0xFF442B72),
                        ),
                        controller: _emailController,
                        cursorColor: const Color(0xFF442B72),
                        textDirection: (sharedpref?.getString('lang') == 'ar') ?
                        TextDirection.rtl:
                        TextDirection.ltr,
                        scrollPadding:  EdgeInsets.symmetric(
                            vertical: 30),
                        decoration:  InputDecoration(
                          alignLabelWithHint: true,
                          counterText: "",
                          fillColor: const Color(0xFFF1F1F1),
                          filled: true,
                          contentPadding:
                          (sharedpref?.getString('lang') == 'ar') ?
                          EdgeInsets.fromLTRB(0, 0, 17, 40):
                          EdgeInsets.fromLTRB(17, 0, 0, 40),
                          hintText:''.tr,
                          floatingLabelBehavior:  FloatingLabelBehavior.never,
                          hintStyle: const TextStyle(
                            color: Color(0xFF442B72),
                            fontSize: 12,
                            fontFamily: 'Poppins-Light',
                            fontWeight: FontWeight.w400,
                            height: 1.33,
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(7)),
                            borderSide: BorderSide(
                              color: Color(0xFF442B72),
                              width: 0.5,
                            ),),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(7)),
                            borderSide: BorderSide(
                              color: Color(0xFF442B72),
                              width: 0.5,
                            ),
                          ),
                          // enabledBorder: myInputBorder(),
                          // focusedBorder: myFocusBorder(),
                        ),
                      ),
                    ),
                  ),
                  emailError ? Container(): Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 48),
                    child: Text(
                      "Please enter your email".tr,
                      style: TextStyle(color: Colors.red),
                    ),
                  ),
                  SizedBox(
                    height: 35,
                  ),
                  Center(
                    child: ElevatedSimpleButton(
                        txt: 'Save'.tr,
                        fontFamily: 'Poppins-Regular',
                        width: 278,
                        hight: 48,
                        onPress: (){
                          if (_nameController.text.length == 0) {
                            nameError = false;
                            setState(() {

                            });
                          } else if (_nameController.text.length > 0) {
                            nameError = true;
                            setState(() {

                            });
                          }
                          if (_phoneNumberController.text.length < 11) {
                            phoneError = false;
                            setState(() {

                            });
                          } else if (_phoneNumberController.text.length > 10) {
                            phoneError = true;
                            setState(() {

                            });
                          }
                          if (_emailController.text.length < 1) {
                            emailError = false;
                            setState(() {

                            });
                          } else if (_emailController.text.length > 0) {
                            emailError = true;
                            setState(() {

                            });
                          }
                          if( nameError && emailError && phoneError){
                          editAddSupervisor();
                          DataSavedSnackBar(context, 'Data saved successfully');
                          Navigator.pop(context , true);
                          }
                        },
                        color: Color(0xFF442B72),
                        fontSize: 16),
                  ),


                ],
              )
          ),
        ),
        resizeToAvoidBottomInset: false,
        floatingActionButtonLocation:
        FloatingActionButtonLocation.centerDocked,
        floatingActionButton: FloatingActionButton(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(100)),
            backgroundColor: Color(0xff442B72),
            onPressed: () {
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => ProfileSupervisorScreen(
                    // onTapMenu: onTapMenu
                  )));
            },
            child: Image.asset(
              'assets/images/174237 1.png',
              height: 33,
              width: 33,
              fit: BoxFit.cover,
            )

        ),
        bottomNavigationBar: Directionality(
            textDirection: Get.locale == Locale('ar')
                ? TextDirection.rtl
                : TextDirection.ltr,
            child: ClipRRect(
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(25),
                  topRight: Radius.circular(25),
                ),
                child: BottomAppBar(
                    padding: EdgeInsets.symmetric(vertical: 3),
                    height: 60,
                    color: const Color(0xFF442B72),
                    clipBehavior: Clip.antiAlias,
                    shape: const AutomaticNotchedShape(
                        RoundedRectangleBorder(
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(38.5),
                                topRight: Radius.circular(38.5))),
                        RoundedRectangleBorder(
                            borderRadius:
                            BorderRadius.all(Radius.circular(50)))),
                    notchMargin: 7,
                    child: SizedBox(
                        height: 10,
                        child: SingleChildScrollView(
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              GestureDetector(
                                onTap: () {
                                  setState(() {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              HomeForSupervisor()),
                                    );
                                  });
                                },
                                child: Padding(
                                  padding:
                                  (sharedpref?.getString('lang') == 'ar')?
                                  EdgeInsets.only(top:7 , right: 15):
                                  EdgeInsets.only(left: 15),
                                  child: Column(
                                    children: [
                                      Image.asset(
                                          'assets/images/Vector (7).png',
                                          height: 20,
                                          width: 20
                                      ),
                                      SizedBox(height: 3),
                                      Text(
                                        "Home".tr,
                                        style: TextStyle(
                                          fontFamily: 'Poppins-Regular',
                                          fontWeight: FontWeight.w500,
                                          color: Colors.white,
                                          fontSize: 8,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              GestureDetector(
                                onTap: () {
                                  setState(() {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              AttendanceSupervisorScreen()),
                                    );
                                  });
                                },
                                child: Padding(
                                  padding:
                                  (sharedpref?.getString('lang') == 'ar')?
                                  EdgeInsets.only(top: 9, left: 50):
                                  EdgeInsets.only( right: 50, top: 2 ),
                                  child: Column(
                                    children: [
                                      Image.asset(
                                          'assets/images/icons8_checklist_1 1.png',
                                          height: 19,
                                          width: 19
                                      ),
                                      SizedBox(height: 3),
                                      Text(
                                        "Attendance".tr,
                                        style: TextStyle(
                                          fontFamily: 'Poppins-Regular',
                                          fontWeight: FontWeight.w500,
                                          color: Colors.white,
                                          fontSize: 8,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              GestureDetector(
                                onTap: () {
                                  setState(() {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              NotificationsSupervisor()),
                                    );
                                  });
                                },
                                child: Padding(
                                  padding:
                                  (sharedpref?.getString('lang') == 'ar')?
                                  EdgeInsets.only(top: 12 , bottom:4 ,right: 10):
                                  EdgeInsets.only(top: 8 , bottom:4 ,left: 20),
                                  child: Column(
                                    children: [
                                      Image.asset(
                                          'assets/images/Vector (2).png',
                                          height: 17,
                                          width: 16.2
                                      ),
                                      Image.asset(
                                          'assets/images/Vector (5).png',
                                          height: 4,
                                          width: 6
                                      ),
                                      SizedBox(height: 2),
                                      Text(
                                        "Notifications".tr,
                                        style: TextStyle(
                                          fontFamily: 'Poppins-Regular',
                                          fontWeight: FontWeight.w500,
                                          color: Colors.white,
                                          fontSize: 8,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              GestureDetector(
                                onTap: () {
                                  setState(() {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              TrackSupervisor()),
                                    );
                                  });
                                },
                                child: Padding(
                                  padding:
                                  (sharedpref?.getString('lang') == 'ar')?
                                  EdgeInsets.only(top: 10 , bottom: 2 ,right: 10,left: 0):
                                  EdgeInsets.only(top: 8 , bottom: 2 ,left: 0,right: 10),
                                  child: Column(
                                    children: [
                                      Image.asset(
                                          'assets/images/Vector (4).png',
                                          height: 18.36,
                                          width: 23.5
                                      ),
                                      SizedBox(height: 3),
                                      Text(
                                        "Buses".tr,
                                        style: TextStyle(
                                          fontFamily: 'Poppins-Regular',
                                          fontWeight: FontWeight.w500,
                                          color: Colors.white,
                                          fontSize: 8,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ))))));
  }
}
