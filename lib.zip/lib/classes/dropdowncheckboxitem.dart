class DropdownCheckboxItem {
  final String label;
  bool isChecked;
  DropdownCheckboxItem({required this.label, this.isChecked = false});
}