import 'package:flutter/cupertino.dart';

class NotificationMessage{
  String messageContent;
  String messageType;
  String messageTime;
  String messageTimes;
  NotificationMessage({
    required this.messageContent, required this.messageType, required this.messageTime, required this.messageTimes
  });
}